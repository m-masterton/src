#!/bin/sh

xmenu <<EOF | sh &
Development
	Emacs
	IntelliJ
	Code		code
	vim			st -e "nvim"
System
	Htop		st -e "htop"
	Lxappearance	lxappearance
	PCManFM		pcmanfm
Productivity
	Texmaker	texmaker
	Zathura		zathura
Graphics
	Nomacs		nomacs
	vlc		vlc
Internet
	Surf		surf
	Firefox		firefox
	Mutt		st -e "mutt"
	Discord		discord
	Newsboat	st -e "newsboat"

Terminal (st)		st

Shutdown		poweroff
Reboot			reboot
EOF
